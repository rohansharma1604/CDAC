class CheckPositiveNum{
	public static void main(String args []){
	int a = 5;
	if (a>0){
		System.out.println("Positive no.");	
	}
	else{
		System.out.println("No. not positive");
	}
	}
}