class CheckNegativeNum{
	public static void main(String args[]){
	int a = -5;
	if(a<0){
		System.out.println("No. -ve");
	}
	else{
		System.out.println("No.not -ve");
	}
	}
}