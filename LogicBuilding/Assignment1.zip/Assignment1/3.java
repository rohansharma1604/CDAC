class CheckOddEven{
	public static void main(String args[]){
	int a = 32;
	if(a%2==0){
		System.out.println(a+" " + "is an even no.");
	}
	else{
		System.out.println(a+ " " + "is an odd no.");
	}
	}
}