class GoodMorning {
	public static void main(String[] args) {
    	int currentTime = 1224;
	if(currentTime > 0500 && currentTime < 1200){
		System.out.println("Godd morning pineapple looking v good v nice!");
	}
	else if(currentTime >= 1200 && currentTime < 1700){
		System.out.println("Good afternoon!");
	}
	else if(currentTime >= 1200 && currentTime < 1700){
		System.out.println("Good afternoon!");
	}
	else if(currentTime >= 1700 && currentTime < 2000){
		System.out.println("Good evening");
	} 
	else{
		System.out.println("Good evening");
	}   
	}
}