class AreaOfSquare{
	public static void main(String args[]){
	int a = 5;     // a is the length of a side of a Square
	int A = a*a;   // A is the area of the Square
	System.out.println("The area of the square is: "+ A);
	}
}