class AreaOfRect{
	public static void main(String args[]){
	int l = 5;       // length of the rectangle
	int b = 15;      // breadth of the rectangle
	int A = l*b;     // Area of the rectangle
	System.out.println("The area of the rectangle is: " + A);
	}
}