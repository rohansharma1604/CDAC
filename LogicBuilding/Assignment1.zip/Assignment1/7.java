class LargestNum{
	public static void main(String args[]){
	int a = 31;
	int b = 244;
	int c = 300;
	if(a > b){
		if(a>c){
			System.out.println(a + " is the largest num");
		}
		else{
			System.out.println(c + " is the largest num");
		}
	}
	else{
		if(b>c){
			System.out.println(b + " is the largest num");
		}
		else{
			System.out.println(c + " is the largest num");
		}
	}

	}
}

		
	