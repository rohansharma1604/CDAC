public class Main15 { 
    public static void main(String[] args) { 
        int num1 = 10; 
        double num = 5.5; 
	int num2 = (int) Math.floor(num);
        int result = num1 + num2; 
        System.out.println(result); 
    } 
}