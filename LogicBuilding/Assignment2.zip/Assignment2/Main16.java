public class Main16 { 
    public static void main(String[] args) { 
        int num = 10;	
	double num2 = num;
        double result = num2 / 4; 
        System.out.println(result); 
    } 
} 