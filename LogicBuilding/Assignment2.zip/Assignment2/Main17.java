public class Main17 {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;
        int result = a * b;
        System.out.println(result);
    }
}