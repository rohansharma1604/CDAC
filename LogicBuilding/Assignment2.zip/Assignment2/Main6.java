public class Main6 { 
    public static void main(String args[]) { 
	int y = 1;
        int x = y + 10; 
        System.out.println(x); 
    } 
} 