public class Confusion { 
    public static void main(String[] args) { 
        int value = 2; 
        switch(value) { 
            case 1: 
                System.out.println("Value is 1");
		break; 
            case 2: 
                System.out.println("Value is 2");
		break; 
            case 3: 
                System.out.println("Value is 3");
		break; 
            default: 
                System.out.println("Default case");
		break;
        } 
    } 
} 