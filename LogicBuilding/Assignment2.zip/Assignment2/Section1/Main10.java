public class Main10 { 
    
    public static void main(String args[]) { 
	String num = "TestNum";
        System.out.println("No parameters");

        System.out.println("With parameter: " + num);

     
        System.out.println("");
        System.out.println(5); 
    
    } 
   
}