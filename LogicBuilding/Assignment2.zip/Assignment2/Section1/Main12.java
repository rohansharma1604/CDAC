public class Main12 {
    public static void main(String[] args) {
	int a = 10;
        while (a>0) {      
            System.out.println("Finite Loop" + " " + a);
	    a--;
        }
    }
}


// changind condition assuming the desired code should yield limited number of outcomes