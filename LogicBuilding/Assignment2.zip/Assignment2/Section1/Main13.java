public class Main13 { 
    public static void main(String[] args) { 
        String str = ""; 
        System.out.println(str.length()); 
    } 
} 