public class Main21 { 
    public static void main(String[] args) { 
        System.out.println("Hello, World!"); 
    }
}