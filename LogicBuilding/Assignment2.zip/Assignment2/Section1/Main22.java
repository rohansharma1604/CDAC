public class Main22 { 
    public static void main(String[] args) { 
        System.out.println("Message"); 
    } 
} 