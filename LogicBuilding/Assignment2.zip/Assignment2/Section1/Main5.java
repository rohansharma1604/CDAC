public class Main5 { 
    public static void main(String args[]) { 
        System.out.println("Main method with String[] args"); 
        System.out.println("Overloaded main method with int[] args"); 
    } 
}