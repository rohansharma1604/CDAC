public class Main7 { 
    public static void main(String args[]) { 
        int x = 7;
        System.out.println(x);
    }
}