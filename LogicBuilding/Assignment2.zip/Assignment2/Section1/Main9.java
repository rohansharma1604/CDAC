public class Main9 { 
    public static void main(String args[]) { 
        int c = 10; 
        System.out.println(c); 
    } 
} 