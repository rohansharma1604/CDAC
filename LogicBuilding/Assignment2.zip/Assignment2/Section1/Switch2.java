public class Switch2 {
    public static void main(String[] args) {
        double scoreOG = 85.0;
	int score = (int) scoreOG;
	System.out.println(score);
        switch(score) {
            case 100:
                System.out.println("Perfect score!");
                break;
            case 85:
                System.out.println("Great job!");
                break;
            default:
                System.out.println("Keep trying!");
		break;
        }
    }
}