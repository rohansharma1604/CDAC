public class Switch3 { 
    public static void main(String[] args) { 
        int number = 5; 
        switch(number) { 
            case 5: 
                System.out.println("Number is 5"); 
 
 
                break;  
            default: 
                System.out.println("This is the default case"); 
        } 
    } 
} 