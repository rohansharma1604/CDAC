public class Test { 
    public static void main(String[] args) { 
        while (true) { 
            System.out.println("Infinite Loop");
        }
    }
}