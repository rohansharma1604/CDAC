class Ques1 {
	public static void main(String args[]){
		int marks = 70;
		if (marks>=90){
			System.out.println("A");
		}
		else if (marks >= 80 && marks <= 89){
			System.out.println("B");
		}
		else if (marks >= 70 && marks <= 79){
			System.out.println("C");
		}
		else if (marks >= 60 && marks <= 69){
			System.out.println("D");
		}
		else if (marks < 60){
			System.out.println("F");
		}
		else {
			System.out.println("Error:Unexpected input");
		}
		
	}
}




