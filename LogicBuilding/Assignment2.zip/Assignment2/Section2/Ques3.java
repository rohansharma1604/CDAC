class Ques3 {
	public static void main(String args[]){
		int a = 10;
		int b = 0;
		String s = "/";
		switch (s) {
			case "/":
				if (b == 0){
					System.out.println("Error: Division by 0 is not allowed");
				}
				else{
					System.out.println("The int division: "+ (a/b));
				}
				
				break;
			case "-":
				System.out.println("The diff: "+ (a-b));
				break;
			case "*":
				System.out.println("The multiplicatn: "+ (a*b));
				break;
			case "+":
				System.out.println("The sum: "+ (a+b));
				break;
			default:
				System.out.println("Unexpected op");
		}

	}
}
