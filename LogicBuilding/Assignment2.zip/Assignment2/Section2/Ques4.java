class Ques4 {
	public static void main(String args[]){
		boolean membership = true;
		int discount = 0;
		int purchase = 680;
		
		if (purchase>=1000){
			discount = 20;
		}
		else if (purchase<=999 && purchase>=500){
			discount = 10;
		}
		else {
			discount = 5;
		}
		System.out.println("discount % before checking membership: " + discount);
		if (membership){
			discount = discount+5;
			
		}
		else {
			// discount will remain 0
		}
		double doubleDiscount = discount;
		double discountAmnt = purchase*(doubleDiscount/100);
		System.out.println("discount % post membership: " + discount);
		System.out.println("discount amnt: " + discountAmnt);
	}
} 
