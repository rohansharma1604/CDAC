class Ques4 {
	public static void main(String args[]){
		
	}
}