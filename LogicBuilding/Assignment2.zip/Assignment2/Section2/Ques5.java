class Ques5 {
	public static void main(String args[]){
		int a = 30;
		int b = 40;
		int c = 45;
		int failCount = 0;
		int[] allSubjectMarks = {a, b, c};
		for (int i =0; i<= (allSubjectMarks.length-1); i++){
			
			if (allSubjectMarks[i]<40){
				failCount = failCount+1;
				System.out.println("Failed");
			}
			else{
				System.out.println("Passed");	
			}
		}
		System.out.println("failCount: "+failCount);
	}
}

/*Write a program that determines whether a student passes or fails based on their grades in three subjects. If the student scores more than 40 in all subjects, they pass. If the student fails in one or more subjects, print the number of subjects they failed in.*/